import { Component, ViewChild,OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormsModule, NgForm, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserInfo, userlogin } from '../Models/user.model';
import { LoginService } from '../Services/login.service';
import { addUserInfo } from './store/action/userinfo.actions';
import * as fromApp  from '../store/app.reducer';
import { Store } from '@ngrx/store';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  isloginstatus=false;
  loginForm:FormGroup;
  user:userlogin;
  loginres;

  constructor(private router: Router,private formbuilder: FormBuilder,private loginservice:LoginService,private store:Store<fromApp.AppState>) { }

  ngOnInit(): void {
    this.loginForm=this.formbuilder.group({
      username:['admin',Validators.required],
      password:['admin',Validators.required],
    });
    this.loginservice.GetUserdetails();
  }

  get getControl(){
    return this.loginForm.controls;
  }
 
  onlogin=():any=>{
    console.log(this.loginForm);
    const objuser=new userlogin();
    objuser.username=this.loginForm.get('username').value;
    objuser.password=this.loginForm.get('password').value;
    this.user=objuser;
    this.loginres=this.loginservice.loginvalidation(this.user);
    
    if(this.loginres===false){
       this.isloginstatus=true;
    }else{
      this.isloginstatus=false;
      this.store.dispatch(addUserInfo(this.loginres));

       if(this.loginres.Role==='Admin'){
         this.router.navigate(['./admindashboard']);
       }else if (this.loginres.Role=='User'){
        this.router.navigate(['./customerdashboard']);
       }
       
    }
  }
}
