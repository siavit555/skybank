import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { reducer, userFeatureKey } from './store/reducer/userinfo.reducer';
import { StoreModule } from '@ngrx/store';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FormsModule,
    StoreModule.forFeature(userFeatureKey,reducer)
  ],
  exports:[]
})
export class UserinfoModule { }
