import { createAction, props,Action } from '@ngrx/store';
import { UserInfo } from 'src/app/Models/user.model';

export const addUserInfo = createAction(
  '[UserInfo] Load UserInfos',
  (userinfo:UserInfo)=>({userinfo})
);






