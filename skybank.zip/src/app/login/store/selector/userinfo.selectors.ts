import { createFeatureSelector, createSelector } from '@ngrx/store';

import * as fromuser from '../reducer/userinfo.reducer';

export const selectUserState=createFeatureSelector<fromuser.UserState>(
    fromuser.userFeatureKey
);


export const selectUsers=createSelector(
    selectUserState,
    (state:fromuser.UserState)=>state.userinfos
); 