import { Action, createReducer, on } from '@ngrx/store';
import * as UserAction from '../action/userinfo.actions';
import { UserInfo } from 'src/app/Models/user.model';


export const userFeatureKey = 'userinfo';
export interface UserState {
  userinfos:UserInfo[];
}

export const initialState: UserState = {
  userinfos:[]
};

export const userreducer = createReducer(
  initialState,
  on(UserAction.addUserInfo,(state:UserState,{userinfo})=>({
    ...state,
    userinfos:[...state.userinfos,userinfo]
  }))
);

export function reducer(state:UserState | undefined,action:Action):any{
  if (action.type === 'CLEAR STATE') {
    state = undefined;
   }
  return userreducer(state,action);
}



