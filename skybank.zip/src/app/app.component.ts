import { Component, OnChanges, OnInit } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { UserInfo } from 'src/app/Models/user.model';
import { selectUsers } from './login/store/selector/userinfo.selectors';
import * as fromApp  from './store/app.reducer';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnChanges {
  title = '';
  isShowDivIf = false;
  loginuserinfo$:Observable<UserInfo[]>;

  constructor(private store: Store<fromApp.AppState>) {
    this.loginuserinfo$=this.store.pipe(select(selectUsers));
   }
   ngOnChanges(){
    this.loginuserinfo$=this.store.pipe(select(selectUsers));
   }
   

  onloginout(): void {
    window.location.href = '/';
  }

    toggleDisplayDivIf() {
        this.isShowDivIf = !this.isShowDivIf;
 
    }
}
