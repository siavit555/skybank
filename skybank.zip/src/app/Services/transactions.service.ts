import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { catchError, map } from "rxjs/operators";
import { Subject, throwError} from "rxjs";

import { transaction } from '../Models/transaction.model';
import { LoginService } from "./login.service";

@Injectable({providedIn:'root'})
export class TransactionService{
    constructor(private http:HttpClient,private loginseervice:LoginService){}
    error=new Subject<string>();
    transactions:transaction[]=[];

    loggedIn=false;
    //Config
    hosturl='https://angulardevlopment-default-rtdb.firebaseio.com/';
    tablename="Transactions.json";

    newtransaction(transactionsdetails:transaction){
        const requrl=this.hosturl+this.tablename;
        return this.http.post<{name:string}>(requrl,transactionsdetails,{
                observe:'response'
            }).subscribe(
                responsedata=>{ 
                   
                }
                ,error=>{
                this.error.next(error.message);
            });
    }

    GetTransactiondetails(){
        let searchparam=new HttpParams();
        const requrl=this.hosturl+this.tablename;
        this.http.get<{[key:string]:transaction}>(requrl,
            {
                headers:new HttpHeaders({'Custom_header':'json'}),
                params:searchparam
            })
        .pipe(
          map(responseData=>{
            const transactions:transaction[]=[];
            for(const key in responseData) {
              if(responseData.hasOwnProperty(key)){
                transactions.push({...responseData[key],id:key});
              }
            }
            return transactions;
          }),catchError(errorres=>{
              return throwError(errorres);
          })
        ).subscribe(response=>{this.transactions=response;});
        
    }

    updateBalancedetails(Accountid:string,BalanceAmmount:number){ 
      const patchurls=this.hosturl+'Accountdetails/' + Accountid + '.json';
      this.http.patch(patchurls,
        {
         Balance :BalanceAmmount
        }
      ).subscribe();
    } 
    
    commonsyncservice(){
        this.GetTransactiondetails();
        this.loginseervice.GetUserdetails();
    }
  
    

}