import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { catchError, map } from "rxjs/operators";
import { Subject, throwError} from "rxjs";

import { UserInfo, userlogin } from '../Models/user.model';

@Injectable({providedIn:'root'})
export class LoginService{
    constructor(private http:HttpClient){}
    error=new Subject<string>();
    userdetails:UserInfo[]=[];

    loggedIn=false;
    //Config
    hosturl='https://angulardevlopment-default-rtdb.firebaseio.com/';
    tablename="Accountdetails.json";

    createnewuser(userdetails:userlogin){
        const requrl=this.hosturl+this.tablename;
        return this.http.post<{name:string}>(requrl,userdetails,{
                observe:'response'
            }).subscribe(
                responsedata=>{ //console.log('test');
                }
                ,error=>{
                this.error.next(error.message);
            });
    }

    GetUserdetails(){
        let searchparam=new HttpParams();
        const requrl=this.hosturl+this.tablename;
        this.http.get<{[key:string]:UserInfo}>(requrl,
            {
                headers:new HttpHeaders({'Custom_header':'json'}),
                params:searchparam
            })
        .pipe(
          map(responseData=>{
            const users:UserInfo[]=[];
            for(const key in responseData) {
              if(responseData.hasOwnProperty(key)){
                users.push({...responseData[key],id:key});
              }
            }
            return users;
          }),catchError(errorres=>{
              return throwError(errorres);
          })
        ).subscribe(response=>{this.userdetails=response;});
        
    }

    updateprofiledetails(profiledetails:UserInfo){
      //console.log('update start');
      //const patchurl='https://angulardevlopment-default-rtdb.firebaseio.com/Accountdetails/-M_sYfZFRSkPKYS5UKja.json';
      const patchurls=this.hosturl+'Accountdetails/' + profiledetails.id + '.json';
      //console.log(patchurls);
      this.http.patch<UserInfo>(patchurls,
        {
         address :profiledetails.address,
         password:profiledetails.password
        }
      ).subscribe();
      this.GetUserdetails();
    } 
    
    loginvalidation(user:userlogin){
        let itemIndex = this.userdetails.findIndex(usr => usr.username == user.username && usr.password==user.password);
        if(itemIndex >= 0){
          this.loggedIn=true;
          return this.userdetails[itemIndex]
        }else{
          this.loggedIn=false;
          return false;
        }
    }

    isAuthenticated(){
      const promise=new Promise(
          (resolve,reject)=>{
              setTimeout(() => {
                  resolve(this.loggedIn)  
              }, 1000);
          }
      );
      return promise;
    }

}