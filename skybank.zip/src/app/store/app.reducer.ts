import * as fromuserinforeducer from '../login/store/reducer/userinfo.reducer';
import { ActionReducerMap } from '@ngrx/store';


export interface AppState{
    UserList:fromuserinforeducer.UserState
}

export const appReducer: ActionReducerMap<AppState>={
    UserList:fromuserinforeducer.userreducer
}