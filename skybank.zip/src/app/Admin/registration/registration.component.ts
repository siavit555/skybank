import { HttpClient } from '@angular/common/http';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { Validators,FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { UserInfo } from '../../Models/user.model';
import { map } from 'rxjs/operators';
import { LoginService } from 'src/app/Services/login.service';
import { Observable, Subscription } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit,OnDestroy {
  UserregForm:FormGroup;
  successalert=false;
  genders=['Male','Female'];
  UsersType=['User','Admin'];
  AccountTypes=['Savings Account','Current Account','Checking Account'];
  Userlist:UserInfo[]=[];
  IsFecthcingdata=false;
  IsAnyExpectionOccured=null;
  private errorSub:Subscription;
  constructor(private http:HttpClient,private loginservice:LoginService,private formbuilder: FormBuilder,
    private router:Router) { }

  ngOnInit(): void {
    this.errorSub= this.loginservice.error.subscribe(errormessage=>{
      this.IsAnyExpectionOccured=errormessage;
    });
    this.UserregForm=this.formbuilder.group({
      accountno:[Date.now()],
      //usertype:['',Validators.required],
      title:['',Validators.required],
      firstname:['',Validators.required],
      lastname:['',Validators.required],
      email:['',[Validators.required,Validators.email]],
      gender:['',Validators.required],
      mobilenumber:['',Validators.required],
      dateofbirth:['',Validators.required],
      address:['',Validators.required],
      username:['',Validators.required],
      password:['',[Validators.required,Validators.minLength(4)]],
      confirmpassword:['',[Validators.required]],
      accounttype:['',Validators.required],
      accepttemandconditions:['',[Validators.required]],
    });
    this.Refresh();
  }

  
  onsubmit(){
    let postdata:UserInfo={
      accountno:this.UserregForm.get('accountno').value,
      Role:'User',
      title:this.UserregForm.get('title').value,
      firstname:this.UserregForm.get('firstname').value,
      lastname:this.UserregForm.get('lastname').value,
      email:this.UserregForm.get('email').value,
      gender:this.UserregForm.get('gender').value,
      mobilenumber:this.UserregForm.get('mobilenumber').value,
      dateofbirth:this.UserregForm.get('dateofbirth').value,
      address:this.UserregForm.get('address').value,
      username:this.UserregForm.get('username').value,
      password:this.UserregForm.get('password').value,
      accounttype:this.UserregForm.get('accounttype').value,
      accepttemandconditions:this.UserregForm.get('accepttemandconditions').value,
      Balance:500
    };
   
    
    //Get Service Call
    this.loginservice.createnewuser(postdata)
    // .subscribe(res=>{console.log(res)}
    // ,error=>{
    //   this.IsFecthcingdata=false;
    //   this.IsAnyExpectionOccured=error;
    // });

    this.successalert=true;
    setTimeout(() => {
      this.successalert=false;
      //this.router.navigate(['./']);
    }, 3000);
    
    this.Refresh();
  }

  Refresh(){
    this.UserregForm.reset();
    this.UserregForm.setValue({
      accountno:Date.now(),
      accounttype:'Savings Account',
      title:'Mr',
      firstname:'',
      lastname:'',
      email:'',
      gender:'Male',
      mobilenumber:'',
      dateofbirth:'',
      address:'',
      username:'',
      password:'',
      confirmpassword:'',
      accepttemandconditions:''
    });
  }

  get getControl(){
    return this.UserregForm.controls;
  }

  

  
  closeerror(){
    this.IsFecthcingdata=false;
    this.IsAnyExpectionOccured=null;
  }

  ngOnDestroy(){
    this.errorSub.unsubscribe();
  }

}
