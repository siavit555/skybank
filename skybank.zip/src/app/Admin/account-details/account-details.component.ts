import { Component, OnInit } from '@angular/core';
import { UserInfo } from 'src/app/Models/user.model';
import { LoginService } from '../../Services/login.service';

@Component({
  selector: 'app-account-details',
  templateUrl: './account-details.component.html',
  styleUrls: ['./account-details.component.css']
})
export class AccountDetailsComponent implements OnInit {
  userdetails:UserInfo[]=[];
  constructor(private accountdetails:LoginService) { }

  ngOnInit() {
    this.onloadAccountdetails();
  }

  onloadAccountdetails(){
    this.userdetails=this.accountdetails.userdetails;
  }

}
