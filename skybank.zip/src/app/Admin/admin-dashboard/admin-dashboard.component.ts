import { Component, OnChanges, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { select, Store } from '@ngrx/store';
import { Observable, Subscription } from 'rxjs';
import { UserInfo } from 'src/app/Models/user.model';
import { LoginService } from 'src/app/Services/login.service';
import { selectUsers } from '../../login/store/selector/userinfo.selectors';
import * as fromApp  from '../../store/app.reducer';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {
  loginuserinfo$:Observable<UserInfo[]>;
  userinfos:UserInfo[] = [];
  constructor(private store: Store<fromApp.AppState>) {
    this.loginuserinfo$=this.store.pipe(select(selectUsers));
    this.loginuserinfo$.subscribe(countries => this.userinfos = countries);
   }

  ngOnInit(): void {
  }

}
