import { Component, OnInit } from '@angular/core';
import { transaction } from 'src/app/Models/transaction.model';
import { select, Store } from '@ngrx/store';
import { Observable, Subject } from 'rxjs'; 
import { UserInfo } from 'src/app/Models/user.model';
import * as fromApp  from '../../store/app.reducer';
import { selectUsers } from '../../login/store/selector/userinfo.selectors';
import { TransactionService } from 'src/app/Services/transactions.service';
import * as XLSX from 'xlsx'; 
import { LoginService } from 'src/app/Services/login.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { formatDate } from '@angular/common';

@Component({
  selector: 'app-all-transaction',
  templateUrl: './all-transaction.component.html',
  styleUrls: ['./all-transaction.component.css']
})
export class AllTransactionComponent implements OnInit {

  loginuserinfo$:Observable<UserInfo[]>;
  userinfos:UserInfo[] = [];
  transactions:transaction[]=[];
  Accountno;
  fileName= 'ExcelSheet_'+Date.now()+'.xlsx'; 
  SearchForm:FormGroup;
  fromdate;
  todate;
  constructor(private transservice:TransactionService,private store: Store<fromApp.AppState>
    ,private formbuilder: FormBuilder
    ,private loginservice:LoginService) { 
    this.transservice.GetTransactiondetails();
    this.loginuserinfo$=this.store.pipe(select(selectUsers));
    this.loginuserinfo$.subscribe(countries => this.userinfos = countries);
  }

  ngOnInit() {
    let date=new Date();
    this.SearchForm=this.formbuilder.group({
      formdate:['',Validators.required],//formatDate(date,'dd-MM-yyyy','en-US')
      todate:['',Validators.required],
      searchtern:['',Validators.required]
    }); 
    this.Accountno=this.userinfos[0].accountno;
    setTimeout(() => {
      this.transactions=this.transservice.transactions;
    }, 3000);
  }

  get getControl(){
    return this.SearchForm.controls;
  }
  
  onsearch(){
    var pattern = /(\d{2})\.(\d{2})\.(\d{4})/;
    this.fromdate=this.SearchForm.get('formdate').value;
    //console.log(this.fromdate);
    //this.fromdate=this.fromdate.replace(pattern,'$3-$2-$1');
    
    
    this.todate=this.SearchForm.get('todate').value;
    this.todate.setDate(this.todate.getDate() + 1);
    //this.todate=this.todate.replace(pattern,'$3-$2-$1');
    console.log(this.todate);

    const searchtern=this.SearchForm.get('searchtern').value;
    this.transservice.GetTransactiondetails();
    
    setTimeout(() => {
      console.log(this.transservice.transactions);
      debugger;
      this.transactions=this.transservice.transactions.filter(
        x=>((new Date(x.Transactiontimestamp) >=this.fromdate)
        && (new Date(x.Transactiontimestamp) <=this.todate)) 
        || ((x.Fromaccountnumber.toString()==searchtern) || (x.Toaccountnumber.toString()==searchtern) )
        );
    }, 3000);
  }
  
exportexcel(): void 
{
   /* table id is passed over here */   
   let element = document.getElementById('tbltransactionhistory'); 
   const ws: XLSX.WorkSheet =XLSX.utils.table_to_sheet(element);

   /* generate workbook and add the worksheet */
   const wb: XLSX.WorkBook = XLSX.utils.book_new();
   XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

   /* save to file */
   XLSX.writeFile(wb, this.fileName);
  
}

}
