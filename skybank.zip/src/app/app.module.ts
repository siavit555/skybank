import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
//import { StoreModule } from '@ngrx/store';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './Admin/registration/registration.component';
import { CustomerDashboardComponent } from './Customer/customer-dashboard/customer-dashboard.component';
import { AdminDashboardComponent } from './Admin/admin-dashboard/admin-dashboard.component';
import { AuthGuard } from './Services/auth-guard.service';
import { UserinfoModule } from './login/userinfo.module';
import { StoreModule } from '@ngrx/store';
import * as  app  from './store/app.reducer';
import { AccountDetailsComponent } from './Admin/account-details/account-details.component';
import { ProfileComponent } from './Customer/profile/profile.component';
import { TransactionsComponent } from './Customer/transactions/transactions.component';
import { DatePipe } from '@angular/common';
import { TransactionHistoryComponent } from './Customer/transaction-history/transaction-history.component';
import { AllTransactionComponent } from './Admin/all-transaction/all-transaction.component';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegistrationComponent,
    CustomerDashboardComponent,
    AdminDashboardComponent,
    AccountDetailsComponent,
    ProfileComponent,
    TransactionsComponent,
    TransactionHistoryComponent,
    AllTransactionComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    UserinfoModule,
    StoreModule.forRoot(app.appReducer),
    BrowserAnimationsModule,
    BsDatepickerModule.forRoot() 
  ],
  providers: [AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
