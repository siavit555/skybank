import { Component, OnInit } from '@angular/core';
import { transaction } from 'src/app/Models/transaction.model';
import { select, Store } from '@ngrx/store';
import { Observable, Subscription } from 'rxjs';
import { UserInfo } from 'src/app/Models/user.model';
import * as fromApp  from '../../store/app.reducer';
import { selectUsers } from '../../login/store/selector/userinfo.selectors';
import { TransactionService } from 'src/app/Services/transactions.service';
import * as XLSX from 'xlsx'; 

@Component({
  selector: 'app-transaction-history',
  templateUrl: './transaction-history.component.html',
  styleUrls: ['./transaction-history.component.css']
})
export class TransactionHistoryComponent implements OnInit {
  loginuserinfo$:Observable<UserInfo[]>;
  userinfos:UserInfo[] = [];
  transactions:transaction[]=[];
  Accountno;
  fileName= 'ExcelSheet_'+Date.now()+'.xlsx'; 
  constructor(private transservice:TransactionService,private store: Store<fromApp.AppState>) { 
    this.transservice.GetTransactiondetails();
    this.loginuserinfo$=this.store.pipe(select(selectUsers));
    this.loginuserinfo$.subscribe(countries => this.userinfos = countries);
  }

  ngOnInit() {
    this.Accountno=this.userinfos[0].accountno;
    this.transactions=this.transservice.transactions.filter(X => X.Fromaccountnumber === this.Accountno || X.Toaccountnumber === this.Accountno);
  }

  
exportexcel(): void 
{
   /* table id is passed over here */   
   let element = document.getElementById('tbltransactionhistory'); 
   const ws: XLSX.WorkSheet =XLSX.utils.table_to_sheet(element);

   /* generate workbook and add the worksheet */
   const wb: XLSX.WorkBook = XLSX.utils.book_new();
   XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

   /* save to file */
   XLSX.writeFile(wb, this.fileName);
  
}
}
