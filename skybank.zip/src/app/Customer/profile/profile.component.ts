import { Component, OnChanges, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { select, Store } from '@ngrx/store';
import { Observable, Subscription } from 'rxjs';
import { UserInfo } from 'src/app/Models/user.model';
import { LoginService } from 'src/app/Services/login.service';
import { selectUsers } from '../../login/store/selector/userinfo.selectors';
import * as fromApp  from '../../store/app.reducer';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  loginuserinfo$:Observable<UserInfo[]>;
  UserregForm:FormGroup;
  successalert=false;
  genderss=['Male','Female'];
  AccountTypes=['Savings Account','Current Account','Checking Account'];
  Userlist:UserInfo[]=[];
  IsFecthcingdata=false;
  IsAnyExpectionOccured=null;
  private errorSub:Subscription;
  userinfos:UserInfo[] = [];
  Accountno;
  yourbalance:number=0;
  userid;

  ngOnInit() {
    this.UserregForm=this.formbuilder.group({
      accountno:[Date.now()],
      //usertype:['',Validators.required],
      title:['',Validators.required],
      firstname:['',Validators.required],
      lastname:['',Validators.required],
      email:['',[Validators.required,Validators.email]],
      gender:['',Validators.required],
      mobilenumber:['',Validators.required],
      dateofbirth:['',Validators.required],
      address:['',Validators.required],
      username:['',Validators.required],
      password:['',[Validators.required,Validators.minLength(4)]],
      confirmpassword:['',[Validators.required]],
      accounttype:['',Validators.required],
      accepttemandconditions:['',[Validators.required]],
    });
    this.getuserinfo();
  }
   constructor(private store: Store<fromApp.AppState>,private formbuilder: FormBuilder,private loginservice:LoginService) {
    this.loginuserinfo$=this.store.pipe(select(selectUsers));
    this.loginuserinfo$.subscribe(countries => this.userinfos = countries);
   }


   getuserinfo(){
     console.log(this.userinfos);
    this.UserregForm=this.formbuilder.group({
      accountno:[this.userinfos[0].accountno],
      title:[this.userinfos[0].title,Validators.required],
      firstname:[this.userinfos[0].firstname,Validators.required],
      lastname:[this.userinfos[0].lastname,Validators.required],
      email:[this.userinfos[0].email,[Validators.required,Validators.email]],
      gender:[this.userinfos[0].gender,Validators.required],
      mobilenumber:[this.userinfos[0].mobilenumber,Validators.required],
      dateofbirth:[this.userinfos[0].dateofbirth,Validators.required],
      address:[this.userinfos[0].address,Validators.required],
      username:[this.userinfos[0].username,Validators.required],
      password:[this.userinfos[0].password,[Validators.required,Validators.minLength(4)]],
      confirmpassword:[this.userinfos[0].password,[Validators.required]],
      accounttype:[this.userinfos[0].accounttype,[Validators.required]],
      accepttemandconditions:[true,[Validators.required]],
    });
    this.Accountno=this.userinfos[0].accountno;
    this.yourbalance=this.userinfos[0].Balance;
    this.userid=this.userinfos[0].id;
   }

   get getControl(){
    return this.UserregForm.controls;
  }

  onsubmit(){
    let postdata:UserInfo={
      id:this.userid,
      accountno:this.UserregForm.get('accountno').value,
      Role:'User',
      title:this.UserregForm.get('title').value,
      firstname:this.UserregForm.get('firstname').value,
      lastname:this.UserregForm.get('lastname').value,
      email:this.UserregForm.get('email').value,
      gender:this.UserregForm.get('gender').value,
      mobilenumber:this.UserregForm.get('mobilenumber').value,
      dateofbirth:this.UserregForm.get('dateofbirth').value,
      address:this.UserregForm.get('address').value,
      username:this.UserregForm.get('username').value,
      password:this.UserregForm.get('password').value,
      accepttemandconditions:this.UserregForm.get('accepttemandconditions').value,
      accounttype:this.UserregForm.get('accounttype').value,
      Balance:this.yourbalance
    };
   console.log(postdata);
    this.loginservice.updateprofiledetails(postdata)
    console.log('update end');
    this.successalert=true;
    setTimeout(() => {
      this.successalert=false;
    }, 3000);
    
   
  }
}
