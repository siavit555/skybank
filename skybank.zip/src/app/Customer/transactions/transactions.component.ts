import { Component, OnChanges, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { select, Store } from '@ngrx/store';
import { Observable, Subscription } from 'rxjs';
import { UserInfo } from 'src/app/Models/user.model';
import { LoginService } from 'src/app/Services/login.service';
import { selectUsers } from '../../login/store/selector/userinfo.selectors';
import * as fromApp  from '../../store/app.reducer';
import { DatePipe, formatDate } from '@angular/common';
import { transaction } from 'src/app/Models/transaction.model';
import { TransactionService } from 'src/app/Services/transactions.service';

@Component({
  selector: 'app-transactions',
  templateUrl: './transactions.component.html',
  styleUrls: ['./transactions.component.css']
})
export class TransactionsComponent implements OnInit {
  loginuserinfo$:Observable<UserInfo[]>;
  TransactionForm:FormGroup;
  successalert=false;
  userdetails:UserInfo[]=[];
  IsFecthcingdata=false;
  IsAnyExpectionOccured=null;
  private errorSub:Subscription;
  userinfos:UserInfo[] = [];
  Accountno;
  yourbalance:number=0;
  userid;
 date;
  constructor(private store: Store<fromApp.AppState>,private formbuilder: FormBuilder,private loginservice:LoginService,
    private Transactionservice:TransactionService) {
    this.loginuserinfo$=this.store.pipe(select(selectUsers));
    this.loginuserinfo$.subscribe(countries => this.userinfos = countries);
    this.userdetails=this.loginservice.userdetails;
   }

  ngOnInit(): void {
    this.Transactionservice.commonsyncservice();
    this.getuserinfo();
  }

 

  getuserinfo(){ 
    this.date=new Date();
    this.TransactionForm=this.formbuilder.group({
      Transactionid:['TRN00'+Date.now()],
      Transactiondate:[formatDate(this.date,'dd-MM-yyyy','en-US'),Validators.required],
      Fromaccountnumber:[this.userinfos[0].accountno,Validators.required],
      Toaccountnumber:['',[Validators.required]],
      Balanceondate:[this.userinfos[0].Balance,Validators.required],
      Transactionamount:['',Validators.required],
      Transactionremarks:['',Validators.required],
    });   
    console.log(this.userinfos[0]);
    this.Accountno=this.userinfos[0].accountno;
    this.yourbalance=this.userinfos[0].Balance;
    this.userid=this.userinfos[0].id;
   }
   get getControl(){
    return this.TransactionForm.controls;
  }
  onsubmit(){
    const toaccno=this.TransactionForm.get('Toaccountnumber').value;
    console.log(toaccno);
    console.log(this.userdetails);
    const touserinfo=this.userdetails.filter(X => X.accountno === toaccno);
   console.log(touserinfo);

   if(touserinfo[0].id !== '' && touserinfo[0].id !== undefined)
   {
    this.date=new Date();
    let postdata:transaction={
      Transactionid:this.TransactionForm.get('Transactionid').value,
      Transactiondate:this.TransactionForm.get('Transactiondate').value,
      Transactiontype:'Debit',
      Fromaccountnumber:this.TransactionForm.get('Fromaccountnumber').value,
      Toaccountnumber:this.TransactionForm.get('Toaccountnumber').value,
      Balanceondate:this.TransactionForm.get('Balanceondate').value,
      Transactionamount:this.TransactionForm.get('Transactionamount').value,
      Transactionremarks:this.TransactionForm.get('Transactionremarks').value,
      Transactiontimestamp:this.date,
      Transactionstatus:'Completed'
    };
    //Debit
    const transamt=this.TransactionForm.get('Transactionamount').value;
    const currbal=(this.yourbalance-transamt);
    //Credit
    const prevbal= touserinfo[0].Balance;
    const newbal=(prevbal+transamt);

    // console.log(this.yourbalance);
    // console.log(transamt);
    // console.log(currbal);

    //Get Service Call
    this.Transactionservice.newtransaction(postdata)
    //Debit Amt
    this.Transactionservice.updateBalancedetails(this.userid,currbal);
    //Credit Amt
    this.Transactionservice.updateBalancedetails(touserinfo[0].id,newbal);

    this.Transactionservice.commonsyncservice();
    this.successalert=true;
    setTimeout(() => {
      this.successalert=false;
      //this.router.navigate(['./']);
    }, 3000);
    
    this.getuserinfo()
  }
  else{
    alert("invaild account No")
  }
  }
}
