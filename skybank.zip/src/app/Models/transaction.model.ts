export class transaction {
    id?:string;
    Transactionid:number;
    Transactiondate:string;
    Transactiontype:string;
    Fromaccountnumber:string;
    Toaccountnumber:string;
    Balanceondate:string;
    Transactionamount:number;
    Transactionremarks:string;
    Transactiontimestamp:string;
    Transactionstatus:string;
}