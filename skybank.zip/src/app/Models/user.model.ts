export class userlogin{
username:string;
password:string;
}

export class UserInfo{
    id?:string;
    accountno:number;
    Role:string;
    title:string;
    firstname:string;
    lastname:string;
    gender:string;
    email:string;
    username:string;
    password:string;
    dateofbirth:string;
    mobilenumber:string;
    address:string;
    Balance:number;
    accounttype:string;
    accepttemandconditions:string;
}