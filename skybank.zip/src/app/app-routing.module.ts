import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AccountDetailsComponent } from './Admin/account-details/account-details.component';
import { AdminDashboardComponent } from './Admin/admin-dashboard/admin-dashboard.component';
import { AllTransactionComponent } from './Admin/all-transaction/all-transaction.component';
import { RegistrationComponent } from './Admin/registration/registration.component';
import { CustomerDashboardComponent } from './Customer/customer-dashboard/customer-dashboard.component';
import { ProfileComponent } from './Customer/profile/profile.component';
import { TransactionHistoryComponent } from './Customer/transaction-history/transaction-history.component';
import { TransactionsComponent } from './Customer/transactions/transactions.component';
import { LoginComponent } from './login/login.component';
import { AuthGuard } from './Services/auth-guard.service';

const routes: Routes = [
  {path:'', component:LoginComponent},
  //Admin
  {path:'usersignupform',canActivate:[AuthGuard], component:RegistrationComponent},
  {path:'admindashboard',canActivate:[AuthGuard], component:AdminDashboardComponent},
  {path:'accountsummary',canActivate:[AuthGuard], component:AccountDetailsComponent},
  //Customer
  {path:'customerdashboard',canActivate:[AuthGuard], component:CustomerDashboardComponent},
  {path:'profile',canActivate:[AuthGuard], component:ProfileComponent},
  {path:'transaction',canActivate:[AuthGuard], component:TransactionsComponent},
  {path:'transactionhistory',canActivate:[AuthGuard], component:TransactionHistoryComponent},
  {path:'alltransactionhistory',canActivate:[AuthGuard], component:AllTransactionComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
